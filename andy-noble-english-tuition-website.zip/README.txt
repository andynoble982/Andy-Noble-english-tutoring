# Andy Noble English Tuition Website

This is a simple, responsive static website.

## Use it online
The site only needs the `index.html` file, so it can be published using a static website host such as GitHub Pages, Netlify, or Vercel.

## Important
The contact details in the page are:
- Email: andynoble982@gmail.com
- Phone: +44 07562 253420

There is no backend or booking system yet. The contact buttons open the visitor's email or phone app.
